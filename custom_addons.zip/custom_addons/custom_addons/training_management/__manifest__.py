# -*- coding: utf-8 -*-
{
    'name': "Internal Training Management",

    'summary': "Module to manage internal training",
    'author': "Hussian Ahmed",
    'category': 'Human Resources',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base', 'hr'],
    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/course_views.xml'
        # 'security/record_rules.xml',
        # 'data/sequences.xml',
        # 'views/menu.xml',
        # 'views/registration_views.xml',
        # 'views/room_views.xml',
        # 'views/teacher_views.xml',
        # 'views/location_views.xml',
        # 'views/my_courses_views.xml',   
    ],
    'installable': True,
    'application': True,
}

