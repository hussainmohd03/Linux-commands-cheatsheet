# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date 


class Course(models.Model):
    _name = "training.course"
    _description = "Training Course"
    
    name = fields.Char(string="Course Name", required=True)
    serial_number = fields.Char(string="Serial Number", readonly=True, copy=False, default='New')
    description = fields.Text(string="Course Description")
    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date", required=True)
    number_of_days = fields.Integer(string="Number of Days", compute="_compute_number_of_days", store=True)
    deadline = fields.Date(string="Registration Deadline")
    time = fields.Char(string="Course Time")
    target_gender = fields.Selection([('male', 'Male'), ('female', 'Female')], string="Target Gender")
    available_seats = fields.Integer(string="Available Seats", required=True)

    # Relationships
    room_id = fields.Many2one('training.room', string="Training Room")
    location_id = fields.Many2one('training.location', string="Training Location")
    teacher_id = fields.Many2one('hr.employee', string="Instructor")



    # Constraints
    @api.constrains('start_date', 'end_date')
    def _check_dates(self):
        for record in self:
            if record.start_date and record.end_date:
                if record.end_date < record.start_date:
                    raise ValidationError("End Date cannot be earlier than Start Date.")

    # Compute Methods
    @api.depends('start_date', 'end_date')
    def _compute_number_of_days(self):
        for record in self:
            if record.start_date and record.end_date:
                record.number_of_days = (record.end_date - record.start_date).days + 1
            else:
                record.number_of_days = 0
    
    # Override create method to set serial number
    @api.model_create_multi
    def create(self, values):
        for val in values:
            if val.get('serial_number', 'New') == 'New':
                val['serial_number'] = self.env['ir.sequence'].next_by_code('training.course') or 'New'
        return super(Course, self).create(values)