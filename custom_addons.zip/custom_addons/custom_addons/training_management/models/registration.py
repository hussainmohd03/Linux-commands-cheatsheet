from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date


class Registration(models.Model):
    _name = "training.registration"
    _description = "Training Registration"

    serial_number = fields.Char(string="Serial Number", readonly=True, copy=False, default='New')
    state = fields.Selection(
    [
        ('draft', 'Draft'),
        ('pending', 'Pending Approval'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ],
    default='draft',
    string="Status")

    # Relationships
    course_id = fields.Many2one('training.course', string="Course", required=True, domain="[('end_date','>=',context_today())]")
    employee_id = fields.Many2one('hr.employee', string="Employee", default=lambda self: self.env.user.employee_id, readonly=True)
    
    # Related Fields
    description = fields.Text(related='course_id.description', readonly=True)
    teacher_id = fields.Many2one(related='course_id.teacher_id', readonly=True)
    start_date = fields.Date(related='course_id.start_date', readonly=True)
    end_date = fields.Date(related='course_id.end_date', readonly=True)
    number_of_days = fields.Integer(related='course_id.number_of_days', readonly=True)
    time = fields.Char(related='course_id.time', readonly=True)
    room_id = fields.Many2one(related='course_id.room_id', readonly=True)
    location_id = fields.Many2one(related='course_id.location_id', readonly=True)


    @api.constrains('course_id')
    def _check_available_seats(self):
        for rec in self:
            if rec.course_id.available_seats <= 0:
                raise ValidationError("Seats are full")

    @api.constrains('employee_id')
    def _check_six_months(self):
        for rec in self:
            if rec.employee_id.joining_date:
                days = (date.today() - rec.employee_id.joining_date).days
                if days < 180:
                    raise ValidationError("Employee must complete 6 months before registering")
                
    @api.constrains('employee_id')
    def _check_one_course_per_year(self):
        year_start = date.today().replace(month=1, day=1)
        for rec in self:
            count = self.search_count([
                ('employee_id', '=', rec.employee_id.id),
                ('create_date', '>=', year_start),
                ('state', '!=', 'rejected')
            ])
            if count > 1:
                raise ValidationError("Only one course per year is allowed")

    @api.constrains('employee_id')
    def _check_pending_request(self):
        for rec in self:
            pending = self.search_count([
                ('employee_id', '=', rec.employee_id.id),
                ('state', 'in', ['draft', 'teacher'])
            ])
            if pending > 1:
                raise ValidationError("You already have a pending registration")


    #override create to set serial number
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code('training.registration') or 'New'
        return super(Registration, self).create(vals_list)
    
    
    # action methods
    
    def action_approve(self):
        for rec in self:
            if rec.state != 'pending':
                raise ValidationError("Only pending registrations can be approved.")

            course = rec.course_id

            if course.available_seats <= 0:
                raise ValidationError("Seats are full.")

            course.available_seats -= 1

            rec.state = 'approved'

    def action_reject(self):
        for rec in self:
            
            if rec.state != 'pending' and rec.state != 'approved':
                raise ValidationError("Only pending or approved registrations can be rejected.")
            
            if rec.state == 'approved':
                rec.course_id.available_seats += 1
                
        rec.state = 'rejected'

    
    def action_submit(self):
        for rec in self:
            if rec.state == 'ap'
        self.state = 'pending'
