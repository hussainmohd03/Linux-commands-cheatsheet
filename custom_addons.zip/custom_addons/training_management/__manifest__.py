# -*- coding: utf-8 -*-
{
    'name': "Internal Training Management",

    'summary': "Module to manage internal training",
    'author': "Hussian Ahmed",
    'category': 'Human Resources',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base', 'hr'],
    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
    ],
    'installable': True,
    'application': True,
}

