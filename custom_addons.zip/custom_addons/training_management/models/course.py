# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date 


class Course(models.Model):
    _name = "training.course"
    _description = "Training Course"
    
    name = fields.Char(string="Course Name", required=True)
    serial_number = fields.Char(string="Serial Number", readonly=True, copy=False, default='New')
    description = fields.Text(string="Course Description")
    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")
    number_of_days = fields.Integer(string="Number of Days", compute="_compute_number_of_days")
    deadline = fields.Date(string="Registration Deadline")
    time = fields.Char(string="Course Time")
    target_geneder = fields.Selection([('male', 'Male'), ('female', 'Female')], string="Gender")
    available_seats = fields.Integer(string="Available Seats", required=True)
    
    # Relationships
    room_id = fields.Many2one('training.room', string="Training Room")
    location_id = fields.Many2one('training.location', string="Training Location")
    teacher_id = fields.Many2one('hr.employee', string="Instructor")
 
 
    @api.constrains('start_date', 'end_date')
    def _check_dates(self):
        for record in self:
            if record.start_date and record.end_date:
                if record.end_date < record.start_date:
                    raise ValidationError("End Date cannot be earlier than Start Date.")
                if record.end_date < date.today():
                    raise ValidationError("End Date cannot be in the past.")

    @api.depends('start_date', 'end_date')
    def _compute_number_of_days(self):
        for record in self:
            if record.start_date and record.end_date:
                record.number_of_days = (record.end_date - record.start_date).days + 1
            else:
                record.number_of_days = 0
                
    @api.api.model_create_multi
    def create(self, values):
        for val in values:
            if val.get('serial_number', 'New') == 'New':
                val['serial_number'] = self.env['ir.sequence'].next_by_code('training.course') or 'New'
        return super(Course, self).create(values)