# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date 


class Course(models.Model):
    _name = "training.course"
    _description = "Training Course"
    
    name = fields.Char(string="Course Name", required=True)
    serial_number = fields.Char(string="Serial Number", copy=False, default="New")
    description = fields.Text(string="Course Description")
    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date", required=True)
    number_of_days = fields.Integer(string="Number of Days", compute="_compute_number_of_days", store=True)
    deadline = fields.Date(string="Registration Deadline")
    time = fields.Datetime(string="Course Time", required=True)
    target_gender = fields.Selection([('male', 'Male'), ('female', 'Female')], string="Target Gender")
    available_seats = fields.Integer(string="Available Seats", required=True)

    # Relationships
    room_id = fields.Many2one('training.room', string="Training Room")
    location_id = fields.Many2one('training.location', string="Training Location")
    teacher_id = fields.Many2one('hr.employee', string="Instructor", required=True)



    # Constraints
    @api.constrains('start_date', 'end_date')
    def _check_dates(self):
        for record in self:
            if record.start_date and record.end_date:
                if record.end_date < record.start_date:
                    raise ValidationError("End Date cannot be earlier than Start Date.")
                
    
    @api.constrains('deadline', 'start_date')
    def _check_deadline(self):
        for record in self:
            if record.deadline and record.start_date:
                if record.deadline > record.start_date:
                    raise ValidationError("Registration Deadline cannot be later than Start Date.")


    # @api.constrains('teacher_id')
    # def _check_teacher(self):
    #     for record in self:
    #         if record.teacher_id and not record.teacher_id.isTeacher:
    #             raise ValidationError("The selected instructor is not an teacher.")

    # Compute Methods
    @api.depends('start_date', 'end_date')
    def _compute_number_of_days(self):
        for record in self:
            if record.start_date and record.end_date:
                record.number_of_days = (record.end_date - record.start_date).days + 1
            else:
                record.number_of_days = 0
    