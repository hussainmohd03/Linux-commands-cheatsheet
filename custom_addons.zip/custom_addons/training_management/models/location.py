from odoo import models, fields, api


class Location(models.Model):
    _name = "training.location"
    _description = "Training Location"

    name = fields.Char(string="Location Name", required=True)
    code = fields.Char(string="code", required=True)