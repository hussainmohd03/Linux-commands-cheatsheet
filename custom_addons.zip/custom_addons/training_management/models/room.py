from odoo import models, fields, api


class Room(models.Model):
    _name = "training.room"
    _description = "Training Room"

    name = fields.Char(string="Room Name", required=True)
    code = fields.Char(string="code", required=True)